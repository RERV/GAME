#include "bullet.h"

Bullet::Bullet()
{
  //  this->_type()="bullet";
    this->_needtime=300;
    this->_attackplayer=20;
    this->_attackenemy=20;
    this->_velocity=50;



}

Bullet::~Bullet()
{

}


