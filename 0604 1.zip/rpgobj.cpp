#include "rpgobj.h"
#include <iostream>
extern string path;
void RPGObj::initObj(string type)
{   _hp=100;
    //TODO 所支持的对象类型应定义为枚举

    this->_coverable = false;
    _direction = rand()%4;
    this->_icon = ICON::findICON(type);
    QImage all;
    string thepath=path;
    thepath+=("picture\\"+type+" (1).png");
    const char* path1=thepath.c_str();
    all.load(path1);
    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

void RPGObj::show(QPainter * pa)
{
    int gSize = ICON::GRID_SIZE;
    QTransform trans;
    trans.translate(+this->getPosX()*66+33,+this->getPosY()*66+33);
    trans.rotate(90*_direction);
    trans.translate(-this->getPosX()*66-33,-this->getPosY()*66-33);
    pa->setWorldTransform(trans);
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}

void RPGObj::move(int direction, int steps){
    switch (direction){
        case 2:
            this->_pos_y += steps;
            break;
        case 0:
            this->_pos_y -= steps;
            break;
        case 3:
            this->_pos_x -= steps;
            break;
        case 1:
            this->_pos_x += steps;
            break;
    }
}

