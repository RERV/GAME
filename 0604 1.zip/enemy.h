#ifndef ENEMY_H
#define ENEMY_H
#include "rpgobj.h"
#include"bullet.h"
class Enemy : public RPGObj,Bullet
{
public:
    Enemy();
    ~Enemy();
    void initEnemy();
    void setBullet(Bullet *k);
    Bullet getBullet(){
        return _bullet;
    }
    void setBullet(Bullet &a){
        _bullet=a;
    }

private:
    Bullet _bullet;

};

#endif // ENEMY_H
