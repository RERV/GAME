#include "bullet.h"

Bullet::Bullet()
{
  //  this->_type()="bullet";
    this->_needtime=300;
    this->_attack=20;
    this->_velocity=50;



}

Bullet::~Bullet()
{

}


